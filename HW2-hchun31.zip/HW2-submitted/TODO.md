- [x] Decouple html, css, js
- [x] Use firefox
- [x] Local HTTP server (python or unix command)

- [ ] d3 slides
- [ ] Folder structureope